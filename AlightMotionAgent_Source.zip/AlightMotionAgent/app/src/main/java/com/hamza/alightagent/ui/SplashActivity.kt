package com.hamza.alightagent.ui

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.animation.ScaleAnimation
import androidx.appcompat.app.AppCompatActivity
import com.hamza.alightagent.R

/**
 * Branded "Hamza Creator" intro: the glowing Jarvis orb fades in,
 * the name reveals line by line, and the opening jingle plays.
 * Hands off to [MainActivity] after ~4 seconds.
 */
class SplashActivity : AppCompatActivity() {

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var launched = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        supportActionBar?.hide()
        setContentView(R.layout.activity_splash)

        // Orb pops in with a scale animation.
        findViewById<View>(R.id.splashOrb).startAnimation(
            ScaleAnimation(
                0.3f, 1f, 0.3f, 1f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f
            ).apply { duration = 900 }
        )

        // Texts fade in one after another.
        listOf(R.id.tvPresents, R.id.tvBrand, R.id.tvAppName, R.id.tvTagline)
            .forEachIndexed { i, id ->
                findViewById<View>(id).startAnimation(
                    AlphaAnimation(0f, 1f).apply {
                        duration = 700
                        startOffset = 400L + i * 250L
                    }
                )
            }

        // Opening jingle + "Welcome Boss! Jarvis hazir hai!"
        try {
            player = MediaPlayer.create(this, R.raw.app_intro)?.apply { start() }
        } catch (_: Exception) {
            // Intro plays best-effort; the splash still works without sound.
        }

        handler.postDelayed({ goNext() }, 4200)
    }

    private fun goNext() {
        if (launched) return
        launched = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
