package com.hamza.alightagent.api

import com.hamza.alightagent.data.AgentPlan
import com.hamza.alightagent.data.UiAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * The AI "brain": calls Gemini (free tier) over plain REST and turns
 * a voice command plus a screen dump into a structured [AgentPlan].
 *
 * No paid SDK is used — just OkHttp + org.json, both free.
 *
 * Resilience: tries models in order, with exponential backoff on
 * HTTP 429 (quota) and 503 (server busy), so temporary Google
 * overload never surfaces as a hard error to the user.
 */
class GeminiApiClient(private val apiKey: String) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    // Primary model first; the second is a fallback if the first is overloaded.
    private val models = listOf(
        "gemini-3-flash-preview",
        "gemini-flash-latest"
    )

    private fun endpointFor(model: String): String =
        "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

    /**
     * Asks Gemini to plan UI actions for [userCommand] given [screenDump].
     * Retries with backoff on HTTP 429/503, and falls back to the next model.
     */
    suspend fun planActions(userCommand: String, screenDump: String): AgentPlan {
        val prompt = buildPrompt(userCommand, screenDump)
        val bodyString = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put("generationConfig", JSONObject().put("temperature", 0.2))
            .toString()

        var lastError = ""
        for (model in models) {
            val request = Request.Builder()
                .url(endpointFor(model))
                .post(bodyString.toRequestBody("application/json".toMediaType()))
                .build()

            var attempt = 0
            while (attempt < 3) {
                val (code, responseText) = try {
                    withContext(Dispatchers.IO) {
                        client.newCall(request).execute().use { resp ->
                            resp.code to (resp.body?.string().orEmpty())
                        }
                    }
                } catch (e: Exception) {
                    attempt++
                    if (attempt >= 3) {
                        lastError = "Network masla: ${e.message}"
                        break
                    }
                    delay(2000L * attempt)
                    continue
                }

                if ((code == 429 || code == 503) && attempt < 2) {
                    // Quota hit or server busy — back off and retry.
                    attempt++
                    delay(3000L * attempt)
                    continue
                }
                if (code == 200) {
                    return parsePlan(responseText)
                }
                // Non-retryable error, or retries exhausted: try the next model.
                lastError = "Gemini API error $code: ${responseText.take(200)}"
                break
            }
        }
        throw RuntimeException(
            "Gemini server busy hai ($lastError). Thodi der baad dobara try karein."
        )
    }

    /** Builds the instruction + context prompt sent to Gemini. */
    private fun buildPrompt(userCommand: String, screenDump: String): String = """
        You are the brain of an Android automation agent controlling Alight Motion (a mobile video editor) through accessibility taps.
        The user speaks Roman Urdu or English. You see the current screen as a list of visible texts with [x,y] center coordinates.

        Reply with RAW JSON only (no markdown fences), exactly this shape:
        {
          "reasoning": "short explanation",
          "speakText": "short Roman Urdu reply to speak to the user",
          "needsApproval": false,
          "actions": [
            {"type":"TAP_TEXT","text":"Effects"},
            {"type":"TAP_BOUNDS","x":540,"y":900},
            {"type":"TYPE_TEXT","target":"Search","text":"shake"},
            {"type":"SWIPE","x1":540,"y1":1500,"x2":540,"y2":600},
            {"type":"LAUNCH_APP","package":"com.alightcreative.motion"},
            {"type":"BACK"},
            {"type":"WAIT","ms":1000}
          ]
        }
        Rules:
        - Use only these 7 action types. Keep actions minimal (max 8 per reply); prefer TAP_TEXT over TAP_BOUNDS.
        - "speakText" must be short Roman Urdu (e.g. "Theek hai, effect laga raha hoon.").
        - Set needsApproval=true for delete/export/share/upload/payment actions.
        - If the screen dump is empty or the target is not visible, use WAIT or BACK; never invent coordinates.
        - TYPE_TEXT "target" is the visible label near the input field.

        USER COMMAND: $userCommand

        CURRENT SCREEN (text [x,y]):
        $screenDump
    """.trimIndent()

    /** Parses Gemini's JSON reply into an [AgentPlan]. */
    private fun parsePlan(responseText: String): AgentPlan {
        val root = JSONObject(responseText)
        var text = root.getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
            .trim()
        // Strip accidental markdown fences.
        if (text.startsWith("```")) {
            text = text.removePrefix("```json").removePrefix("```").trim()
            if (text.endsWith("```")) text = text.removeSuffix("```").trim()
        }
        val plan = JSONObject(text)
        val actions = mutableListOf<UiAction>()
        val arr = plan.optJSONArray("actions") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            when (a.optString("type")) {
                "TAP_TEXT" -> actions.add(UiAction.TapText(a.optString("text")))
                "TAP_BOUNDS" -> actions.add(UiAction.TapBounds(a.optInt("x"), a.optInt("y")))
                "TYPE_TEXT" -> actions.add(
                    UiAction.TypeText(a.optString("target"), a.optString("text"))
                )
                "SWIPE" -> actions.add(
                    UiAction.Swipe(a.optInt("x1"), a.optInt("y1"), a.optInt("x2"), a.optInt("y2"))
                )
                "LAUNCH_APP" -> actions.add(UiAction.LaunchApp(a.optString("package")))
                "BACK" -> actions.add(UiAction.Back)
                "WAIT" -> actions.add(UiAction.Wait(a.optLong("ms", 800)))
            }
        }
        return AgentPlan(
            reasoning = plan.optString("reasoning"),
            speakText = plan.optString("speakText", "Ho gaya."),
            actions = actions,
            needsApproval = plan.optBoolean("needsApproval", false)
        )
    }
}
