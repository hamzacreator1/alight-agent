package com.hamza.alightagent.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.hamza.alightagent.R
import com.hamza.alightagent.engine.AgentController
import com.hamza.alightagent.ui.FloatingOrbView
import com.hamza.alightagent.ui.MainActivity

/**
 * Foreground service hosting the floating Jarvis orb
 * (WindowManager.TYPE_APPLICATION_OVERLAY) and the Allow/Deny approval cards.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var instance: OverlayService? = null
            private set
        private const val CHANNEL_ID = "alight_agent_channel"
        private const val NOTIF_ID = 1
    }

    private lateinit var windowManager: WindowManager
    private var orbView: FloatingOrbView? = null
    private var orbParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startAsForeground()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val orb = FloatingOrbView(this)
        orbView = orb
        orbParams = WindowManager.LayoutParams(
            280, 280,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 120
            y = 500
        }
        orb.setOnTouchListener(OrbTouchListener())
        windowManager.addView(orb, orbParams)
    }

    override fun onDestroy() {
        orbView?.let { windowManager.removeView(it) }
        orbView = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Updates the orb animation state. Must be called on the main thread. */
    fun setOrbState(state: FloatingOrbView.OrbState) {
        orbView?.setState(state)
    }

    /**
     * Shows a modal Allow/Deny approval card above other apps.
     * Both callbacks run on the main thread.
     */
    fun showApprovalCard(message: String, onAllow: () -> Unit, onDeny: () -> Unit) {
        val view = LayoutInflater.from(this)
            .inflate(R.layout.view_approval_card, null)
        view.findViewById<TextView>(R.id.tvApprovalMessage).text = message
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setView(view)
            .setCancelable(false)
            .create()
        view.findViewById<Button>(R.id.btnAllow).setOnClickListener {
            dialog.dismiss()
            onAllow()
        }
        view.findViewById<Button>(R.id.btnDeny).setOnClickListener {
            dialog.dismiss()
            onDeny()
        }
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.show()
    }

    /** Distinguishes a tap (→ talk to the agent) from a drag (→ move the orb). */
    private inner class OrbTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = orbParams?.x ?: 0
                    startY = orbParams?.y ?: 0
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) moved = true
                    orbParams?.let {
                        it.x = startX + dx
                        it.y = startY + dy
                        windowManager.updateViewLayout(orbView, it)
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) AgentController.onOrbTap()
                    return true
                }
            }
            return false
        }
    }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Alight AI Agent", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Alight AI Agent chal raha hai")
            .setContentText("Orb dabao aur bolo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }
}
