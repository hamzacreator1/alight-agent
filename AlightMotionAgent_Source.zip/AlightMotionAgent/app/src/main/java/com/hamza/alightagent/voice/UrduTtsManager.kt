package com.hamza.alightagent.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Voice output using Android's built-in (free) TextToSpeech,
 * preferring an Urdu (Pakistan) voice with device-default fallback.
 */
class UrduTtsManager(context: Context) {

    private var tts: TextToSpeech? = null

    /** Called on the main thread when an utterance finishes or errors. */
    var onDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("ur", "PK"))
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    // Fall back to the device default language.
                    tts?.language = Locale.getDefault()
                }
                tts?.setPitch(1.0f)
                tts?.setSpeechRate(0.95f)
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { /* no-op */ }
            override fun onDone(utteranceId: String?) { onDone?.invoke() }
            override fun onError(utteranceId: String?) { onDone?.invoke() }
        })
    }

    /** Speaks [text], interrupting anything currently spoken (barge-in). */
    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alight-agent-utterance")
    }

    /** Stops current speech immediately. */
    fun stop() {
        tts?.stop()
    }

    /** Releases the TTS engine. Call from Application/Service teardown. */
    fun shutdown() {
        try {
            tts?.shutdown()
        } catch (_: Exception) { /* ignore */ }
        tts = null
    }
}
