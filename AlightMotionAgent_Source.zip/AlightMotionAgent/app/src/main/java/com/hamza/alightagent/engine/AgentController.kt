package com.hamza.alightagent.engine

import android.accessibilityservice.AccessibilityService
import android.content.Context
import com.hamza.alightagent.api.GeminiApiClient
import com.hamza.alightagent.data.UiAction
import com.hamza.alightagent.service.AgentAccessibilityService
import com.hamza.alightagent.service.OverlayService
import com.hamza.alightagent.ui.FloatingOrbView
import com.hamza.alightagent.voice.SpeechManager
import com.hamza.alightagent.voice.UrduTtsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * The orchestrator: voice command → AI plan → speak reply + execute actions.
 *
 * Singleton for the app process. MainActivity initializes it; OverlayService
 * routes orb taps here; SpeechManager routes recognized commands here.
 */
object AgentController {

    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var apiKey: String = ""
    private lateinit var speech: SpeechManager
    private lateinit var tts: UrduTtsManager
    private var job: Job? = null

    /** Mirrors events into MainActivity's log view. */
    var onLog: ((String) -> Unit)? = null

    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        speech = SpeechManager(appContext)
        tts = UrduTtsManager(appContext)
        speech.listener = object : SpeechManager.Listener {
            override fun onCommand(text: String) {
                OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.THINKING)
                handleCommand(text)
            }

            override fun onError(message: String) {
                OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.IDLE)
                speakNow("Dobara bolein, samajh nahi aaya.")
            }

            override fun onListeningStarted() {
                OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.LISTENING)
            }
        }
    }

    fun setApiKey(key: String) {
        apiKey = key.trim()
    }

    /**
     * Called when the orb is tapped: barges in (stops any speech)
     * and starts listening for a command.
     */
    fun onOrbTap() {
        tts.stop()
        OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.LISTENING)
        if (speech.isAvailable()) {
            speech.startListening()
        } else {
            onLog?.invoke("SpeechRecognizer available nahi hai.")
            speakNow("Voice recognition available nahi hai.")
            OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.IDLE)
        }
    }

    /** Runs one full command cycle: plan → speak → (approve) → execute. */
    fun handleCommand(text: String) {
        job?.cancel()
        job = scope.launch {
            onLog?.invoke("Command: $text")
            val svc = AgentAccessibilityService.instance
            if (svc == null) {
                speakNow("Pehle Accessibility permission ON karein (app mein button 1).")
                OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.IDLE)
                return@launch
            }
            if (apiKey.isBlank()) {
                speakNow("Pehle app mein Gemini API key save karein.")
                OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.IDLE)
                return@launch
            }
            try {
                val screen = withContext(Dispatchers.IO) { svc.currentScreenText() }
                val plan = withContext(Dispatchers.IO) {
                    GeminiApiClient(apiKey).planActions(text, screen)
                }
                onLog?.invoke("AI: ${plan.reasoning.take(140)}")
                speakNow(plan.speakText)

                if (plan.needsApproval || isSensitive(text)) {
                    val allowed = askApproval("Ye karun?\n\n${plan.speakText}")
                    if (!allowed) {
                        speakNow("Theek hai, nahi kar raha.")
                        return@launch
                    }
                }
                executeActions(svc, plan.actions)
                speakNow("Ho gaya.")
                onLog?.invoke("Done.")
            } catch (e: Exception) {
                onLog?.invoke("Error: ${e.message}")
                speakNow("Masla ho gaya. ${e.message?.take(60) ?: ""}")
            } finally {
                OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.IDLE)
            }
        }
    }

    /** Keywords that always trigger the Allow/Deny card. */
    private fun isSensitive(text: String): Boolean {
        val t = text.lowercase()
        return listOf(
            "delete", "export", "share", "upload", "payment",
            "buy", "uninstall", "format", "mitao", "hatao", "bhejo"
        ).any { t.contains(it) }
    }

    /** Suspends until the user taps Allow or Deny on the approval card. */
    private suspend fun askApproval(message: String): Boolean =
        suspendCancellableCoroutine { cont ->
            val overlay = OverlayService.instance
            if (overlay == null) {
                if (cont.isActive) cont.resume(false)
                return@suspendCancellableCoroutine
            }
            overlay.showApprovalCard(
                message,
                onAllow = { if (cont.isActive) cont.resume(true) },
                onDeny = { if (cont.isActive) cont.resume(false) }
            )
        }

    /** Executes the AI's action list sequentially with small delays. */
    private suspend fun executeActions(
        svc: AgentAccessibilityService,
        actions: List<UiAction>
    ) {
        for (action in actions) {
            when (action) {
                is UiAction.TapText -> {
                    val node = svc.findNodeByText(action.text)
                    if (node != null) {
                        svc.tapNode(node)
                    } else {
                        onLog?.invoke("'${action.text}' screen par nahi mila")
                    }
                }
                is UiAction.TapBounds -> svc.tapAt(action.x, action.y)
                is UiAction.TypeText -> {
                    val target = svc.findNodeByText(action.targetText)
                        ?: svc.findEditableNode()
                    if (target != null) {
                        svc.tapNode(target)
                        delay(400)
                        svc.typeText(target, action.text)
                    } else {
                        onLog?.invoke("Type karne ki jagah nahi mili")
                    }
                }
                is UiAction.Swipe -> svc.swipe(action.x1, action.y1, action.x2, action.y2)
                is UiAction.LaunchApp -> {
                    if (!svc.launchApp(action.packageName)) {
                        onLog?.invoke("App nahi khul saki: ${action.packageName}")
                    }
                    delay(1500)
                }
                UiAction.Back ->
                    svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                is UiAction.Wait -> delay(action.ms)
            }
            delay(700)
        }
    }

    /** Speaks immediately, switching the orb to SPEAKING state. */
    private fun speakNow(text: String) {
        OverlayService.instance?.setOrbState(FloatingOrbView.OrbState.SPEAKING)
        tts.speak(text)
    }
}
