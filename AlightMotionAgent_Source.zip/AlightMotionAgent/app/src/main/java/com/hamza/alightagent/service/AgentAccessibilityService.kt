package com.hamza.alightagent.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * The agent's "hands": an AccessibilityService that can find on-screen
 * elements by text, tap / swipe / type into them, and launch apps.
 *
 * Enable it in Android Settings → Accessibility → "Alight AI Automation Service".
 */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        /** Static handle so the controller can reach the running service. */
        @Volatile
        var instance: AgentAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used: the agent works on demand, not on accessibility events.
    }

    override fun onInterrupt() { /* no-op */ }

    /**
     * Finds the first node whose visible text or content-description
     * contains [text] (case-insensitive).
     */
    fun findNodeByText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return findNodeByTextRecursive(root, text.lowercase().trim())
    }

    private fun findNodeByTextRecursive(
        node: AccessibilityNodeInfo,
        query: String
    ): AccessibilityNodeInfo? {
        if (query.isNotEmpty()) {
            val label = ((node.text?.toString() ?: "") + " " +
                    (node.contentDescription?.toString() ?: "")).trim()
            if (label.isNotEmpty() && label.lowercase().contains(query)) return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByTextRecursive(child, query)
            if (found != null) return found
        }
        return null
    }

    /** Finds the first editable (text-input) node on screen. */
    fun findEditableNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return findEditableRecursive(root)
    }

    private fun findEditableRecursive(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = node.getChild(i)?.let { findEditableRecursive(it) }
            if (found != null) return found
        }
        return null
    }

    /**
     * Taps a node: tries ACTION_CLICK on it, then on clickable parents,
     * then falls back to a gesture tap at its center.
     */
    fun tapNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable &&
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        ) return true
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable &&
                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) return true
            parent = parent.parent
        }
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return tapAt(rect.centerX(), rect.centerY())
    }

    /** Gesture tap at absolute screen coordinates. */
    fun tapAt(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    /** Swipe gesture from (x1,y1) to (x2,y2). */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 400): Boolean {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    /** Types text into a node via the accessibility set-text action. */
    fun typeText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Launches an installed app by package name. */
    fun launchApp(packageName: String): Boolean {
        return try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
                ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Dumps visible text nodes with their center coordinates — this is what
     * the AI "sees" when planning the next actions.
     */
    fun currentScreenText(): String {
        val root = rootInActiveWindow ?: return "(screen not available)"
        val sb = StringBuilder()
        dumpNode(root, sb, 0)
        val out = sb.toString()
        if (out.isBlank()) return "(no text found on screen)"
        return if (out.length > 6000) out.substring(0, 6000) else out
    }

    private fun dumpNode(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 12 || sb.length > 6000) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val label = text.ifBlank { desc }
        if (label.isNotBlank()) {
            val r = Rect()
            node.getBoundsInScreen(r)
            sb.append("- \"").append(label.replace("\"", "'"))
                .append("\" [").append(r.centerX()).append(",").append(r.centerY())
                .append("]\n")
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { dumpNode(it, sb, depth + 1) }
        }
    }
}
