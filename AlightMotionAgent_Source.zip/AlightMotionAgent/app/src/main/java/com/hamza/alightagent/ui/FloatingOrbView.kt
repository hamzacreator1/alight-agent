package com.hamza.alightagent.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * The Jarvis orb: a glowing animated circle with four states —
 * IDLE (soft pulse), LISTENING (breathing ring), THINKING (rotating arcs),
 * SPEAKING (waveform ripples). ChatGPT/Gemini voice-mode style.
 */
class FloatingOrbView(context: Context) : View(context) {

    /** Visual states of the orb. */
    enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

    private var state: OrbState = OrbState.IDLE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var animPhase = 0f
    private var animator: ValueAnimator? = null

    private val stateColor: Map<OrbState, Int> = mapOf(
        OrbState.IDLE to Color.parseColor("#40C4FF"),
        OrbState.LISTENING to Color.parseColor("#B388FF"),
        OrbState.THINKING to Color.parseColor("#6A1FB0"),
        OrbState.SPEAKING to Color.parseColor("#40C4FF")
    )

    init {
        // BlurMaskFilter requires software rendering.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2400
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                animPhase = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    /** Switches the orb animation state. */
    fun setState(newState: OrbState) {
        state = newState
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val base = (min(width, height) / 2f) * 0.55f
        val color = stateColor[state] ?: Color.CYAN
        val t = Math.toRadians(animPhase.toDouble()).toFloat()

        // Outer glow.
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.maskFilter = BlurMaskFilter(60f, BlurMaskFilter.Blur.NORMAL)
        paint.color = color
        paint.alpha = 90
        val glowR = when (state) {
            OrbState.IDLE -> base * (1.35f + 0.08f * sin(t * 2))
            OrbState.LISTENING -> base * (1.60f + 0.18f * sin(t * 3))
            OrbState.THINKING -> base * 1.45f
            OrbState.SPEAKING -> base * (1.50f + 0.25f * abs(sin(t * 5)))
        }
        canvas.drawCircle(cx, cy, glowR, paint)

        // Core orb with radial gradient.
        paint.maskFilter = null
        paint.alpha = 255
        paint.shader =
            RadialGradient(cx, cy, base, Color.WHITE, color, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, base, paint)
        paint.shader = null

        // State-specific extras.
        when (state) {
            OrbState.THINKING -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 10f
                paint.color = Color.WHITE
                paint.alpha = 200
                val r = base * 1.25f
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                canvas.drawArc(oval, animPhase, 120f, false, paint)
                canvas.drawArc(oval, animPhase + 180f, 120f, false, paint)
            }
            OrbState.LISTENING, OrbState.SPEAKING -> {
                paint.style = Paint.Style.STROKE
                paint.color = color
                paint.strokeWidth = 6f
                for (i in 0..2) {
                    val phase = ((animPhase / 120f) + i) % 3f / 3f
                    paint.alpha = (160 * (1 - phase)).toInt()
                    canvas.drawCircle(cx, cy, base * (1.1f + phase * 0.9f), paint)
                }
            }
            OrbState.IDLE -> { /* glow only */ }
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }
}
