package com.hamza.alightagent.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Voice input using Android's built-in (free) SpeechRecognizer,
 * configured for Urdu (Pakistan) with English fallback.
 */
class SpeechManager(private val context: Context) {

    /** Callbacks for the listening lifecycle. */
    interface Listener {
        /** A final command was recognized. */
        fun onCommand(text: String)

        /** Recognition failed or nothing was understood. */
        fun onError(message: String)

        /** The recognizer started listening (orb → LISTENING). */
        fun onListeningStarted()
    }

    var listener: Listener? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    /** True when on-device/Google recognition is available. */
    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /** Starts one listening session. Safe to call repeatedly — restarts cleanly. */
    fun startListening() {
        stopListening()
        val sr = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = sr
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                listener?.onListeningStarted()
            }

            override fun onBeginningOfSpeech() { /* no-op */ }
            override fun onRmsChanged(rmsdB: Float) { /* no-op */ }
            override fun onBufferReceived(buffer: ByteArray?) { /* no-op */ }
            override fun onEvent(eventType: Int, params: Bundle?) { /* no-op */ }
            override fun onPartialResults(partialResults: Bundle?) { /* no-op */ }

            override fun onEndOfSpeech() {
                listening = false
            }

            override fun onError(error: Int) {
                listening = false
                listener?.onError("Sunnay mein masla (code $error)")
            }

            override fun onResults(results: Bundle?) {
                listening = false
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) listener?.onCommand(text)
                else listener?.onError("Kuch samajh nahi aaya")
            }
        })
        sr.startListening(intent)
    }

    /** Stops listening and releases the recognizer (also used for barge-in). */
    fun stopListening() {
        listening = false
        try {
            recognizer?.stopListening()
        } catch (_: Exception) { /* ignore */ }
        try {
            recognizer?.destroy()
        } catch (_: Exception) { /* ignore */ }
        recognizer = null
    }
}
