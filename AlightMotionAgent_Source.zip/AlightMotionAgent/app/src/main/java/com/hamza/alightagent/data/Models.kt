package com.hamza.alightagent.data

/**
 * One UI action the agent can perform on screen.
 * Produced by the AI brain ([GeminiApiClient]) and executed by
 * [com.hamza.alightagent.service.AgentAccessibilityService].
 */
sealed class UiAction {
    /** Tap the first visible element whose text matches. */
    data class TapText(val text: String) : UiAction()

    /** Tap at absolute screen coordinates. */
    data class TapBounds(val x: Int, val y: Int) : UiAction()

    /** Type [text] into the input near [targetText] (or the focused field). */
    data class TypeText(val targetText: String, val text: String) : UiAction()

    /** Swipe from (x1,y1) to (x2,y2). */
    data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int) : UiAction()

    /** Launch an installed app by package name. */
    data class LaunchApp(val packageName: String) : UiAction()

    /** Press the system back button. */
    object Back : UiAction()

    /** Pause before the next action. */
    data class Wait(val ms: Long) : UiAction()
}

/**
 * A complete plan returned by the AI brain: what it thought,
 * what to say aloud, and which actions to run.
 */
data class AgentPlan(
    val reasoning: String,
    val speakText: String,
    val actions: List<UiAction>,
    val needsApproval: Boolean = false
)
