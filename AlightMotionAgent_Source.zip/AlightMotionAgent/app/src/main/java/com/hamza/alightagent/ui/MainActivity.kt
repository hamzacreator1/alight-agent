package com.hamza.alightagent.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.hamza.alightagent.databinding.ActivityMainBinding
import com.hamza.alightagent.engine.AgentController
import com.hamza.alightagent.service.OverlayService

/**
 * Setup screen: Gemini API key, the 4 permission buttons,
 * the Jarvis orb launcher, and a live log view.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AgentController.init(applicationContext)
        AgentController.onLog = { msg -> runOnUiThread { appendLog(msg) } }

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val savedKey = prefs.getString(KEY_API, "").orEmpty()
        binding.etApiKey.setText(savedKey)
        if (savedKey.isNotBlank()) AgentController.setApiKey(savedKey)

        binding.btnGetKey.setOnClickListener {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))
            )
        }

        binding.btnSaveKey.setOnClickListener {
            val key = binding.etApiKey.text.toString().trim()
            prefs.edit().putString(KEY_API, key).apply()
            AgentController.setApiKey(key)
            appendLog("API key save ho gayi.")
            toast("Save ho gaya")
        }

        binding.btnPermAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Alight AI Automation Service ko ON karein")
        }

        binding.btnPermOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                toast("Overlay permission pehle se mili hui hai")
            }
        }

        binding.btnPermMic.setOnClickListener {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC
            )
        }

        binding.btnPermNotifications.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF
                )
            } else {
                toast("Is Android version par zaroorat nahi")
            }
        }

        binding.btnStartOrb.setOnClickListener {
            if (OverlayService.isRunning()) {
                // Orb is on screen — turn it OFF.
                stopService(Intent(this, OverlayService::class.java))
                appendLog("Orb band ho gaya.")
            } else {
                if (!Settings.canDrawOverlays(this)) {
                    toast("Pehle 'Draw over apps' Allow karein (button 2)")
                    return@setOnClickListener
                }
                ContextCompat.startForegroundService(
                    this, Intent(this, OverlayService::class.java)
                )
                appendLog("Orb start ho gaya — screen par neela gola dekhein, usay dabao aur bolo.")
            }
            updateOrbButton()
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the toggle in case the orb was stopped from the notification.
        if (::binding.isInitialized) updateOrbButton()
    }

    /** Shows "Start" or "Stop (Band karo)" depending on whether the orb is live. */
    private fun updateOrbButton() {
        binding.btnStartOrb.text =
            if (OverlayService.isRunning()) "Stop Jarvis Orb (Band karo)"
            else "Start Jarvis Orb"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
        appendLog(if (granted) "Permission mil gayi." else "Permission nahi mili.")
    }

    private fun appendLog(msg: String) {
        binding.tvLog.append("• $msg\n")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val PREFS = "agent_prefs"
        private const val KEY_API = "gemini_key"
        private const val REQ_MIC = 101
        private const val REQ_NOTIF = 102
    }
}
