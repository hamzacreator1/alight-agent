package com.hamza.alightagent.engine

import android.accessibilityservice.AccessibilityService
import com.hamza.alightagent.service.AgentAccessibilityService
import kotlinx.coroutines.delay

/**
 * Ready-made action sequences for common Alight Motion flows.
 *
 * All steps are best-effort: they match on-screen text and fall back
 * gracefully. Returns true when the flow was attempted, false when a
 * critical step could not be performed.
 */
class AlightMotionWorkflow(private val svc: AgentAccessibilityService) {

    companion object {
        /**
         * Alight Motion's Play Store package name.
         * If Alight Creative ever changes it, update this constant.
         */
        const val ALIGHT_PACKAGE = "com.alightcreative.motion"
    }

    /** Tries each label in order; taps the first one found on screen. */
    private suspend fun tapText(vararg options: String, waitMs: Long = 900): Boolean {
        for (option in options) {
            val node = svc.findNodeByText(option)
            if (node != null && svc.tapNode(node)) {
                delay(waitMs)
                return true
            }
        }
        return false
    }

    /** Opens Alight Motion from the launcher. */
    suspend fun openAlightMotion(): Boolean {
        if (!svc.launchApp(ALIGHT_PACKAGE)) return false
        delay(2500)
        return true
    }

    /** Starts a new project, selecting the given ratio label (e.g. "9:16"). */
    suspend fun newProject(ratio: String = "9:16"): Boolean {
        tapText("+", "Create", "New Project", waitMs = 1200)
        tapText(ratio, "9:16", "16:9", "1:1", waitMs = 800)
        tapText("Create", "Done", "OK", "Start", waitMs = 1500)
        return true
    }

    /** Adds a text layer and types [text] into it. */
    suspend fun addTextLayer(text: String): Boolean {
        if (!tapText("+", "Add", waitMs = 1000)) return false
        if (!tapText("Text", "Aa", waitMs = 1000)) return false
        val editable = svc.findEditableNode()
        if (editable != null) {
            svc.tapNode(editable)
            delay(500)
            svc.typeText(editable, text)
        } else {
            // Fallback: open the text editor explicitly, then type.
            tapText("Edit Text", "Text", waitMs = 800)
            val focused = svc.findEditableNode() ?: return false
            svc.tapNode(focused)
            delay(500)
            svc.typeText(focused, text)
        }
        delay(800)
        tapText("Done", "OK", waitMs = 600)
        return true
    }

    /** Opens the Effects panel for the current layer. */
    suspend fun openEffects(): Boolean {
        return tapText("Effects", "Add Effect", "Effect", waitMs = 1200)
    }

    /** Applies an effect by visible name (e.g. "Shake", "Blur"). */
    suspend fun applyEffect(name: String): Boolean {
        if (!openEffects()) return false
        if (!tapText(name, waitMs = 1000)) return false
        tapText("Done", "OK", "Add", waitMs = 800)
        return true
    }

    /**
     * Opens the share/export flow.
     * NOTE: callers should gate this behind the approval card.
     */
    suspend fun exportProject(): Boolean {
        if (!tapText("Share", "Export", waitMs = 1200)) return false
        tapText("Video", "MP4", waitMs = 800)
        tapText("Export", "Share", "Save", waitMs = 1500)
        return true
    }

    /** Presses the system back button. */
    fun goBack(): Boolean =
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
}
