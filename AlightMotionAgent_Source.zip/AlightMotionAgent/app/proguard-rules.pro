# Keep data models (used for JSON parsing of AI plans).
-keep class com.hamza.alightagent.data.** { *; }
