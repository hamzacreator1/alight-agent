# Alight AI Agent — Android Studio Project

A **free** voice-controlled AI agent for Android that operates **Alight Motion**
by itself: you speak in Roman Urdu, it taps/swipes through the app for you.
Includes a floating Jarvis-style orb with live voice chat.

## What you need (all free)

- A computer (Windows / macOS / Linux) with **Android Studio** (free) —
  download from <https://developer.android.com/studio>
- An Android phone (Android 8.0 / API 26 or newer)
- A free **Gemini API key** from [Google AI Studio](https://aistudio.google.com/apikey)
- Alight Motion installed on the phone

## Build the APK

1. Unzip this project.
2. Open **Android Studio** → **File → Open** → select the `AlightMotionAgent` folder.
3. Wait for the Gradle sync to finish (first run downloads dependencies — needs internet).
4. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When it says "APK(s) generated successfully", click **locate** → copy `app-debug.apk`.

> Requires JDK 17 (Android Studio bundles it: Settings → Build Tools → Gradle → Gradle JDK).

## Install on your phone

1. Copy `app-debug.apk` to your phone (USB cable, WhatsApp, or Google Drive).
2. Tap the file → **Install** (allow "install unknown apps" if Android asks).

## First-run setup (inside the app)

1. Tap **Get FREE key from AI Studio** → sign in with Google → **Create API Key** →
   copy it → paste into the app → **Save Key**.
2. Grant the 4 permissions (one tap each):
   - **1. Accessibility** → find *Alight AI Automation Service* → toggle **ON**
   - **2. Draw over apps** → Allow
   - **3. Microphone** → While using the app
   - **4. Notifications** → Allow
3. Tap **Start Jarvis Orb** → a glowing blue orb appears on your screen.
   Drag it anywhere; tap it to talk.

## Try it (tap the orb, then speak in Roman Urdu)

- "Alight Motion mein naya project banao, 9 by 16 ratio"
- "Is project mein text layer add karo aur likho 'Meri Pehli Video'"
- "Effects mein jao aur is layer par shake effect lagao"
- "Is project ko video format mein export karo" *(asks Allow first)*
- "Meri gallery ki sab se nayi video ka naam batao"
- "Ruk jao" / "Back jao"

## How it works

| Part | Tech (all free) |
|---|---|
| Brain | Gemini 1.5 Flash free tier via REST (`api/GeminiApiClient.kt`), with backoff on HTTP 429 |
| Hands | `AccessibilityService` — taps, swipes, types, launches apps (`service/AgentAccessibilityService.kt`) |
| Voice in | Android built-in `SpeechRecognizer`, `ur-PK` (`voice/SpeechManager.kt`) |
| Voice out | Android built-in `TextToSpeech`, Urdu voice (`voice/UrduTtsManager.kt`) |
| Orb | Floating `TYPE_APPLICATION_OVERLAY` view, 4 animated states (`ui/FloatingOrbView.kt`) |
| Safety | Allow/Deny approval card for delete/export/share/payment (`service/OverlayService.kt`) |
| Alight flows | Ready-made sequences: new project, text layer, effects, export (`engine/AlightMotionWorkflow.kt`) |

## Project structure

```
AlightMotionAgent/
├── settings.gradle.kts
├── build.gradle.kts
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/
        │   ├── xml/accessibility_service_config.xml
        │   ├── layout/activity_main.xml
        │   ├── layout/view_approval_card.xml
        │   ├── drawable/bg_card.xml, bg_button.xml, bg_approval_card.xml
        │   └── values/colors.xml, strings.xml, themes.xml
        └── java/com/hamza/alightagent/
            ├── data/Models.kt
            ├── api/GeminiApiClient.kt
            ├── voice/SpeechManager.kt, UrduTtsManager.kt
            ├── service/AgentAccessibilityService.kt, OverlayService.kt
            ├── ui/FloatingOrbView.kt, MainActivity.kt
            └── engine/AlightMotionWorkflow.kt, AgentController.kt
```

## Limits of the free version

- **Gemini free tier ≈ 15 requests/minute.** The app batches UI steps into few
  calls, but rapid complex jobs may pause ~20–30s on quota.
- **Alight Motion UI changes:** if Alight Creative renames buttons, update the
  label lists in `AlightMotionWorkflow.kt`.
- **Fine controls** (bezier curves, color wheels) are hard by voice — the agent
  does the setup; you fine-tune by hand.
- Built-in speech recognition works best online; for offline Urdu, download the
  Urdu voice pack in Android language settings.

## Notes

- Package: `com.hamza.alightagent` · minSdk 26 · targetSdk 34 · Kotlin + AndroidX.
- Alight Motion package constant: `com.alightcreative.motion`
  (see `AlightMotionWorkflow.ALIGHT_PACKAGE`).
- No data leaves your phone except the screen-text + command sent to the
  Gemini API to plan actions.
